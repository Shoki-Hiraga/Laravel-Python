URLS = [
"https://www.qsha-oh.com/aging-paintcar/",
"https://www.qsha-oh.com/amesha/",
"https://www.qsha-oh.com/classic-supercar/",
"https://www.qsha-oh.com/custom/",
"https://www.qsha-oh.com/damage/",
"https://www.qsha-oh.com/immobile/",
"https://www.qsha-oh.com/itasha/",
"https://www.qsha-oh.com/landcruiser/",
"https://www.qsha-oh.com/ninemania/",
"https://www.qsha-oh.com/other/",
"https://www.qsha-oh.com/repair/",
"https://www.qsha-oh.com/skyoh/",
"https://www.qsha-oh.com/souzoku/",
"https://www.qsha-oh.com/sportscar/",
"https://www.qsha-oh.com/submerged-car/"
]