# ubersuggest
# id = "chaser.cb750@gmail.com"
# password = "78195090Cb"
id = "it@currentmotor.co.jp"
password = "GKAxkv4HJJtY"

# # ahrefs
# id = "it@currentmotor.co.jp"
# password = "ArKaXZYMNx6U"