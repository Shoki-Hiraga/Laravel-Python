Query = [
    "車 買取"
]