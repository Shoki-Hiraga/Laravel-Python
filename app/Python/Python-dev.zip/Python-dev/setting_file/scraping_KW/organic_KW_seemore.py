search_keywords_list = [
'車 買取ランキング',
'車 買取'
    ]