URLS = [
'https://www.qsha-oh.com/maker/nissan/r32-skyline/'
]