URLS = [
'https://www.qsha-oh.com/maker/nissan/skyline/',
'https://ucarpac.com/sell/m002/n027',
'https://autoc-one.jp/ullo/biddedCarList/ma35/mo1639/',
'https://s.kakaku.com/item/70100310105/kaitori/',
'https://www.goo-net.com/kaitori/maker_guide/show/1015/10151010/',
'https://kaitori.carsensor.net/NI/S030/',
'https://221616.com/satei/souba/nissan/skyline/',
'https://autoc-one.jp/catalog/nissan/skyline/kaitori/',
'https://kaitori.carview.co.jp/souba/nissan/skyline/',
'https://www.navikuru.jp/souba/nissan/skyline-sedan/',
'https://www.nextage.jp/kaitori/souba/nissan/skyline/',
'https://www.kurumaerabi.com/kaitori/marketprice/cartype/2/208/'
]
